
// Function.h: Rcpp R/C++ interface class library -- functions (also primitives and builtins)
//
// Copyright (C) 2010 - 2025  Dirk Eddelbuettel and Romain Francois
// Copyright (C) 2026         Dirk Eddelbuettel, Romain François and Iñaki Ucar
//
// This file is part of Rcpp.
//
// Rcpp is free software: you can redistribute it and/or modify it
// under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 2 of the License, or
// (at your option) any later version.
//
// Rcpp is distributed in the hope that it will be useful, but
// WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Rcpp.  If not, see <http://www.gnu.org/licenses/>.

#ifndef Rcpp_Function_h
#define Rcpp_Function_h

#include <RcppCommon.h>

#include <Rcpp/grow.h>

namespace Rcpp{

    /**
     * functions
     */
    RCPP_API_CLASS(Function_Impl) {
    public:

        RCPP_GENERATE_CTOR_ASSIGN(Function_Impl)

        Function_Impl(SEXP x){
            switch( TYPEOF(x) ){
            case CLOSXP:
            case SPECIALSXP:
            case BUILTINSXP:
                Storage::set__(x);
                break;
            default:						// #nocov start
                const char* fmt = "Cannot convert object to a function: "
                                  "[type=%s; target=CLOSXP, SPECIALSXP, or "
                                  "BUILTINSXP].";
                throw not_compatible(fmt, Rf_type2char(TYPEOF(x)));
            }								// #nocov end
        }

        /**
         * Finds a function. By default, searches from the global environment
         *
         * @param name name of the function
         * @param env an environment where to search the function
         * @param ns name of the namespace in which to search the function
         */
        Function_Impl(const std::string& name) {
            get_function(name, R_GlobalEnv);
        }

        Function_Impl(const std::string& name, const SEXP env) {
            if (!Rf_isEnvironment(env)) {
                stop("env is not an environment");
            }
            get_function(name, env);
        }

        Function_Impl(const std::string& name, const std::string& ns) {
#if R_VERSION < R_Version(4,5,0)
            // before R 4.5.0 we would use Rf_findVarInFrame
            Shield<SEXP> env(Rf_findVarInFrame(R_NamespaceRegistry, Rf_install(ns.c_str())));
            if (env == R_UnboundValue)
                stop("there is no namespace called \"%s\"", ns);
#elif R_VERSION < R_Version(4,6,0) || R_SVN_REVISION < 89746
            // during R 4.5.* and before final R 4.6.0 we could use R_getVarEx
            // along with R_NamespaceRegistry but avoid R_UnboundValue
            Shield<SEXP> env(R_getVarEx(Rf_install(ns.c_str()), R_NamespaceRegistry, FALSE, R_NilValue));
            if (env == R_NilValue)
                stop("there is no namespace called \"%s\"", ns);
#else
            // late R 4.6.0 development got us R_getRegisteredNamespace
            Shield<SEXP> env(R_getRegisteredNamespace(ns.c_str()));
            if (env == R_NilValue)
                stop("there is no namespace called \"%s\"", ns);
#endif
            get_function(name, env);
        }

        SEXP operator()() const {
            Shield<SEXP> call(Rf_lang1(Storage::get__()));
            return Rcpp_fast_eval(call, R_GlobalEnv);
        }

        template <typename... T>
        SEXP operator()(const T&... args) const {
            return invoke(pairlist(args...), R_GlobalEnv);
        }

        /**
         * Returns the environment of this function
         */
        SEXP environment() const {
            SEXP fun = Storage::get__() ;
            if( TYPEOF(fun) != CLOSXP ) {
                throw not_a_closure(Rf_type2char(TYPEOF(fun)));
            }
            #if (defined(R_VERSION) && R_VERSION >= R_Version(4,5,0))
            return R_ClosureEnv(fun);
            #else
            return CLOENV(fun);
            #endif
        }

        /**
         * Returns the body of the function
         */
        SEXP body() const {
            return BODY( Storage::get__() ) ;
        }

        void update(SEXP){}


    private:
        void get_function(const std::string& name, const SEXP env) {
            SEXP nameSym = Rf_install( name.c_str() );	// cannot be gc()'ed  once in symbol table
            Shield<SEXP> x( Rf_findFun( nameSym, env ) ) ;
            Storage::set__(x) ;
        }

        SEXP invoke(SEXP args_, SEXP env) const {
            Shield<SEXP> args(args_);
            Shield<SEXP> call(Rcpp_lcons(Storage::get__(), args));
            SEXP out = Rcpp_fast_eval(call, env);
            return out;
        }

    };

    typedef Function_Impl<PreserveStorage> Function ;

} // namespace Rcpp

#endif
